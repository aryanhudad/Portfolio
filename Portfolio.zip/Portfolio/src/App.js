import React from 'react';
//import Contact from './components/contact';
import About from './components/About';
import Header from './components/Header';
//import Navbar from './components/Navbar';


<link rel="stylesheet" href="index.css"></link>
function App() {
  return (
    <>
    <Header/>
    
    <About/>
    </>
  );
}

export default App;
